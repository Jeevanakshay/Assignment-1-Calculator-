import paho.mqtt.client as mqtt

broker_address = "localhost"
broker_port = 1883
topic = "Task"


client = mqtt.Client()


client.connect(broker_address, broker_port)

message = "Hello, Hi!"
client.publish(topic, message)


client.disconnect()